<?php

define('AG_PASSWORD_GENERATOR_DEBUG', 0);

define('AG_PASSWORD_GENERATOR_LOGGING', 1);

define('AG_PASSWORD_GENERATOR_PLUGIN_DIR', plugin_dir_path(__FILE__));
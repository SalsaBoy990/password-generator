# secure-password-generator
A Wordpress plugin that creates a cryptographically save password generator widget. With AJAX.
